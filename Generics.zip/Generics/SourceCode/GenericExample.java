
import java.util.Objects;
interface Comparable<T> 	//Comparable interface
{
	public boolean compareTo(T obj);

}

public class GenericExample<T> implements Comparable
{
	T object1;
	public void setObject(T object1)
	{
		this.object1 = object1;
	}
	public T getObject()
	{
		return this.object1;
	}
	@Override
	public boolean equals(Object new1)
	{
		if(this == new1)
			return true;
		T obj = (T)new1;
		if(Objects.equals(obj, object1))
			return true;
		return false;
	}
	public boolean compareTo(Object obj)
	{
		if(this == obj)
			return true;
		T obj1 = (T)obj;
		if(Objects.equals(obj1, object1))
			return true;
		return false;
	}
	public static void main(String[] args)
	{
		GenericExample<Integer> intObj = new GenericExample<Integer>();
		intObj.setObject(10);
		
		GenericExample<Integer> intObj1 = new GenericExample<Integer>();
		intObj1.setObject(10);
		
		GenericExample<Character> charObj = new GenericExample<Character>();
		charObj.setObject('A');
		
		System.out.println("Getting value of an Integer object: ");
		System.out.println(intObj.getObject());
		System.out.println("Comparing Integer and Character object using equals: ");
		System.out.println(intObj.equals(charObj));
		System.out.println("Comparing two Integer objects having same values using equals: ");
		System.out.println(intObj.equals(intObj1));
		System.out.println("Comparing Integer and Character objects using comparator inteface: ");
		System.out.println(intObj.compareTo(charObj));
		System.out.println("Comparing two Integer objects having same values using comparator inteface: ");
		System.out.println(intObj.compareTo(intObj1));
	}

}
