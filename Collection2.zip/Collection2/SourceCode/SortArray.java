import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeMap;

public class SortArray 
{
	public static void main(String[] args)
	{
		Map<String, Integer> myMap = new HashMap<String, Integer>();
		String s=null;
		String[] input = {"abc","xyz","pqr","xyz","pqr","pqr"};
		for(String str:input)
		{
			if(myMap.containsKey(str))	//If present already
			{
				myMap.put(str,myMap.get(str)+1);	//Increment the count
			}
			else
			{
				myMap.put(str, 1);	//Make new Entry
			}
		}
	
		Set<Entry<String, Integer>> newSet = myMap.entrySet();	//Make entry set for hashmap values
		List<Entry<String, Integer>> newList = new ArrayList<Entry<String, Integer>>(newSet); //Make a list of set values
		Collections.sort(newList, new Comparator<Entry<String, Integer>>()
				{
					@Override
					public int compare(Entry<String,Integer> o1, Entry<String,Integer> o2) {
						return o2.getValue().compareTo(o1.getValue());
				}
				}
				);		//Sort based on values using comparator
		LinkedHashMap<String, Integer> sortedMap = new LinkedHashMap<String, Integer>(); //Make a new map for sorted map
		for(Entry<String, Integer> entry: newList)
		{
			sortedMap.put(entry.getKey(),entry.getValue());
		}
		System.out.println("Sorted in the order of their frequency: ");
		Iterator it1 = sortedMap.entrySet().iterator();
		String[] output = new String[6];
		int n=0;
		while(it1.hasNext())	//Making output String array
		{
			
			Map.Entry entry = (Map.Entry)it1.next();
			output[n++] = entry.getKey().toString();
		}	
		for(int i=0;i<n;i++)
			System.out.println(output[i]);
	}

}
