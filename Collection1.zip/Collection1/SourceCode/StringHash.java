import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;

public class StringHash 
{
	public static void main(String[] args)
	{
		Map<Character, Integer> myMap = new HashMap<Character, Integer>();
		String s=null;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter String: ");
		s = sc.nextLine();
		s = s.toUpperCase();
		System.out.println(s);
		for(int i=0;i<s.length();i++)
		{
			if(myMap.containsKey(s.charAt(i)))	//If present already
				myMap.put(s.charAt(i), myMap.get(s.charAt(i))+1);	//Increment the count
			else
				myMap.put(s.charAt(i), 1);	//Make new Entry
		}
		Iterator it = myMap.entrySet().iterator();	
		Map<Character, String> newMap = new HashMap<Character, String>();
		while(it.hasNext())
		{
			Map.Entry m = (Map.Entry)it.next();
			if((char)m.getKey()>= 'A' && (char)m.getKey()<='Z')		//Only Alphabets
			{
				char ch = (char)m.getKey();
				int n = (int)m.getValue();
				String str="";
				for(int i=0;i<n;i++)str+="#";
				newMap.put(ch,str);
			}
		}
		Iterator it1 = newMap.entrySet().iterator();
		while(it1.hasNext())
		{
			System.out.println(it1.next());
		}
	}

}
